# Loop-engineering section for your global CLAUDE.md

Paste this into your `claude-config` `CLAUDE.md` (the global one at `~/.claude/CLAUDE.md`). It is standing context for how you run coding projects, and it inherits into every project. Keep personal preferences where they already are; this only adds the loop discipline and routing.

---

## Loop engineering (how I run coding projects)

- Design the loop, do not prompt move by move. My job is to set the goal, the loop, the verifier and the critic, then step back.
- Done means the project's `build/verify` gate exits 0, never the model deciding it looks right.
- The maker never grades its own homework: a separate checker or a hard test decides.
- Model routing, and the cheap path is the default path:
  - Sonnet 5 at medium is the workhorse.
  - Escalate genuinely hard reasoning to the strongest model; anything cyber to Opus; cheap read-only mapping to a small model.
  - Escalate the model before cranking effort. A cheap model at maximum effort can cost more than the strong model at medium for less quality.
- Brakes: bounded iterations, an external completion check, and state on disk (`STATE.md`). Stop when stuck rather than spinning.
- Memory: the agent forgets, the repo does not. Durable context lives on disk: `docs/VISION.md`, `STATE.md`, ADRs, and the `openwiki/` codebase wiki. Read `openwiki/` first for codebase context.
- At the start of any project, run `/init-harness`.
